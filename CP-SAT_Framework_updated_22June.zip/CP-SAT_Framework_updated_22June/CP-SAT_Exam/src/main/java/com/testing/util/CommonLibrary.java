package com.testing.util;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonLibrary {
	
	/**
	 * Dynamic wait until element is clickable
	 * @param driver
	 * @param element
	 * @return
	 */
	public WebElement waitForElementToClickable(WebDriver driver, WebElement element) {
		WebElement find;
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(100))
				.pollingEvery(Duration.ofMillis(500)).ignoring(Exception.class);
		find = wait.until(ExpectedConditions.elementToBeClickable(element));
		return find;
	}
	
	/**
	 * Logger for capturing all the logs
	 * @param text
	 */
	public void log(String... text) {
		try {
			String logText="";
			for (String temp: text) {			
				logText+=temp;
			}

			System.out.println(logText);
		} catch (Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * Highlight the Element using java script executor
	 * @param driver
	 * @param element
	 */
	public void highLightElement(WebDriver driver, WebElement element) 
	{
		JavascriptExecutor js=(JavascriptExecutor)driver; 
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		try {
			Thread.sleep(200);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element); 
	}
	
	/**
	 * Click on the element using javascript executor
	 * @param element
	 */
	public void jsClick(WebDriver driver, WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", element);
			log("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-jsClick(): "+e.getMessage());
			takeScreenShot(driver);
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

	/**
	 * Scroll up the page by using coordinators
	 * @throws Exception
	 */
	public void scrollUp(WebDriver driver) throws Exception{
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			log("Page scrolled up");
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-scrollUp(): "+e.getMessage());
			takeScreenShot(driver);
			e.printStackTrace();
			System.out.println("=============================================================");
		}       
	}

	/**
	 * Scroll down the page by using coordinators
	 * @throws Exception
	 */
	public void scrollDown(WebDriver driver) throws Exception{
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,250)", "");
			log("Page scrolled down");   
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-scrollDown(): "+e.getMessage());
			takeScreenShot(driver);
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}

	/**
	 * Scrolls the web page till element is in view
	 * @param element
	 * @param driver
	 */
	public void scrollIntoView(WebElement element, WebDriver driver) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			log("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot(driver);
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}
	
	/**
	 * Takes the screenshot and save in the screen shot in screen shots folder
	 */
	public void takeScreenShot(WebDriver driver) {
		Date date=new Date();
		String screenshotFile=date.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=Constants.REPORT_PATH+"screenshots\\"+screenshotFile;

		try {
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Take screenshot of page and save in screenshots folder including ToolTip
	 * @param folderName
	 * @param picName
	 */
	public void takeScreenShotTip(String folderName,String picName) {
		try {
			Date date = new Date();
			String screenshotFile = date.toString().replace(":", "_").replace(" ", "_");
			String filePath = Constants.REPORT_PATH;
			File output = new File(filePath + "screenshots" + "\\" + folderName + "\\" + screenshotFile + picName + ".png");
			output.mkdir();
			output.createNewFile();
			BufferedImage img = getScreenAsBufferedImg();
			ImageIO.write(img, "png", output);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Takes the screenshot and save in the screen shot in screen shots folder
	 */
	public void takeScreenShot(WebDriver driver, String picName) {
		Date date=new Date();
		String screenshotFile= picName+"_"+date.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=Constants.REPORT_PATH+"screenshots\\"+screenshotFile;

		try {
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void waitUntilPageLoad(WebDriver driver, int pageLoadTimeout) {
		new WebDriverWait(driver, Duration.ofSeconds(pageLoadTimeout)).until(webDriver -> ((JavascriptExecutor) driver)
		.executeScript("return document.readyState").equals("complete"));
		}
	
	
	
	/**
	 * Method to capture screen shot of page as a buffered image
	 * @return
	 */
	public BufferedImage getScreenAsBufferedImg() {
		BufferedImage img = null;
		try {
			Robot r;
			r = new Robot();
			r.keyPress(KeyEvent.VK_PRINTSCREEN);
			wait(1);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			if(clipboard.isDataFlavorAvailable(DataFlavor.imageFlavor)) {
				Transferable transferable = clipboard.getContents(null);
				img = (BufferedImage) transferable.getTransferData(DataFlavor.imageFlavor);
				if(img == null) {
					throw new Exception("Printscreen was unsuccessful. No image content in clipboard.");
				}
			}else {
				throw new Exception("Printscreen was unsuccessful. No image content in clipboard.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return img;
	}
	
	/**
	 * Method for adding Static wait
	 * @param timeToWaitInSec
	 */
	public void wait(int timeToWaitInSec){
		try {
			Thread.sleep(timeToWaitInSec * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * To switch the top most window
	 * @param driver
	 * @throws InterruptedException
	 */
	public void switchWindow(WebDriver driver) throws InterruptedException{
		Set<String> winid = driver.getWindowHandles();
        Iterator<String> iter = winid.iterator();
        iter.next();
        String tab = iter.next();
        Thread.sleep(3000);
        driver.switchTo().window(tab);
	}
	
	/**
	 * Dynamic wait until element is visible
	 * @param driver
	 * @param element
	 * @return
	 */
	public WebElement waitForElementToVisible(WebDriver driver, WebElement element) {
		WebElement find;
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(100))
				.pollingEvery(Duration.ofMillis(500)).ignoring(Exception.class);
		find = wait.until(ExpectedConditions.visibilityOf(element));
		return find;
	}
	
	/**
	 * Method to check the Page is loaded 
	 * @param driver
	 * @throws InterruptedException
	 */
	public void checkPageReady(WebDriver driver) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(5000);
		for (int i = 0; i <= 40; i++) {
			Thread.sleep(1000);
			if (js.executeScript("return document.readyState").toString().equals("complete")) {
				break;
			}
		}
	}
	
	/**
	 * Method to select option from drop down via Index/Text/Value
	 * @param element
	 * @param type
	 * @param text
	 * @param index
	 * @param value
	 */
	public void selectFromDropDown(WebElement element,String type,String text,String index,String value){
		Select slt=new Select(element);
		if(type.equalsIgnoreCase("text")){
			slt.selectByVisibleText(text);
		}else if(type.equalsIgnoreCase("index")){
			slt.selectByIndex(Integer.valueOf(index));
		}else if(type.equalsIgnoreCase("value")){
			slt.selectByValue(value);
		}
	}
	
	/**
	 * To switch to multiple frames in a page and find frame index where the element is present
	 * @param driver
	 * @throws InterruptedException
	 */
	public void framehandle(WebDriver driver) throws InterruptedException{
		try {
		int size = driver.findElements(By.tagName("iframe")).size();
		System.out.println("Number of parent frames: "+size);
		for(int i=0;i<size;i++) {
			System.out.println("Shifting to parent frame: "+i);
			driver.switchTo().frame(i);
			Thread.sleep(2000);
			int size1 = driver.findElements(By.tagName("iframe")).size();
			System.out.println("Number of child frames: "+size1);
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			}
		}catch(Exception e) {
			System.out.println("No frames present");
		}
	}
}

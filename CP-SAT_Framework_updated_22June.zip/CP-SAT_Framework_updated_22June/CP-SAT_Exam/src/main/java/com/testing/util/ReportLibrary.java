package com.testing.util;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ReportLibrary {
	protected String resultColor = "";
	protected static int StNo = 1/* Driver_Script.stepCount */;
	protected static ExtentHtmlReporter htmlReporter;
	protected static ExtentReports extent;
	protected static ExtentTest test;
	protected static String reportDirectory = System.getProperty("user.dir") + "\\Reports\\";
	protected static String finalReportPath = "";
	protected static String tcName;

	/*********************************************************************************************
	 * Description: Method to collect supporting files for HTML report
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param destinationFolder
	 * @param fileNames
	 ********************************************************************************************/
	public void collectReportDependentFiles(String destinationFolder, String fileNames[]) {
		// Create Destination Folder
		new File(destinationFolder).mkdir();

		String sourceFilePath = null;

		for (String fileName : fileNames) {
			sourceFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\" + fileName;
			copyFile(sourceFilePath, destinationFolder);
		}
	}

	/*********************************************************************************************
	 * Description: Method to set prerequisites for HTML Report
	 * 
	 * @author Mohammed Rafi Shaik
	 ********************************************************************************************/
	public void configureReport() {
		if (!new File(reportDirectory).isDirectory()) {
			new File(reportDirectory).mkdir();
		}
		Date dt = new Date();
		SimpleDateFormat sDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		finalReportPath = reportDirectory + "Batch_Exec_" + sDate.format(dt).replace(" ", "_").replace(":", "");
		/*
		 * if(new File(reportPath).isDirectory()) { Common_Library.deleteFolder(new
		 * File(reportPath)); }
		 */
		new File(finalReportPath).mkdir();
		// location of the extent report
		htmlReporter = new ExtentHtmlReporter(finalReportPath + "\\Report.html");
		extent = new ExtentReports(); // create object of ExtentReports
		extent.attachReporter(htmlReporter);
		htmlReporter.config().setDocumentTitle("Automation Report"); // Title of Report
		htmlReporter.config().setReportName("Batch Execution Report"); // Name of the report
		// test = extent.createTest(testName, "Description");
	}

	/****************************************************************
	 * Description: Method to set prerequisites for HTML Report
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param testName
	 * @param testDescription
	 **************************************************************/
	public void createReport(String testName, String testDescription) {
		tcName = testName;
		test = extent.createTest(testName, testDescription);
	}

	/**************************************************************
	 * Description: Method to finalize and open HTML Report
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param testName
	 ************************************************************/
	public void closeReport(String testName) {
		extent.flush();
		/*
		 * try { Desktop.getDesktop().open(new File(reportDirectory + testName
		 * +"\\"+ testName +".html")); } catch (IOException e) {}
		 */
	}

	/********************************************************************
	 * Description: Method to report verdict in the log file.
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param sVerification
	 * @param sActualResult
	 * @param verdict
	 * @param driver
	 * @param isScreenReq
	 *********************************************************************/
	public void logReport(String sVerification, String sActualResult, String verdict, WebDriver driver,
			boolean isScreenReq) {
		try {
			String screenLocation = "";
			switch (verdict.trim().toUpperCase()) {
			case "PASS":
				System.out.println(verdict.toUpperCase() + ": " + sVerification + ", Actual- " + sActualResult);
				if (isScreenReq) {
					screenLocation = new File(captureScreenShot(driver)).getName();
					test.log(Status.PASS, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult,
							MediaEntityBuilder.createScreenCaptureFromPath(screenLocation).build());
				} else {
					test.log(Status.PASS, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult);
				}
				break;
			case "FAIL":
				System.out.println(verdict.toUpperCase() + ": " + sVerification + ", Actual- " + sActualResult);
				if (isScreenReq) {
					screenLocation = new File(captureScreenShot(driver)).getName();
					test.log(Status.FAIL, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult,
							MediaEntityBuilder.createScreenCaptureFromPath(screenLocation).build());
				} else {
					test.log(Status.FAIL, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult);
				}
				// Driver_Script.htmlTestExecStatus = false;
				break;
			case "WARNING":
				System.out.println(verdict.toUpperCase() + ": " + sVerification + ", Actual- " + sActualResult);
				if (isScreenReq) {
					screenLocation = new File(captureScreenShot(driver)).getName();
					test.log(Status.WARNING, sVerification + ", ActualResult: " + sActualResult,
							MediaEntityBuilder.createScreenCaptureFromPath(screenLocation).build());
				} else {
					test.log(Status.WARNING, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult);
				}
				break;
			case "INFO":
				System.out.println(verdict.toUpperCase() + ": " + sVerification + ", Actual- " + sActualResult);
				if (isScreenReq) {
					screenLocation = new File(captureScreenShot(driver)).getName();
					test.log(Status.INFO, sVerification + ", ActualResult: " + sActualResult,
							MediaEntityBuilder.createScreenCaptureFromPath(screenLocation).build());
				} else {
					test.log(Status.INFO, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult);
				}
				break;
			case "FATAL":
				test.log(Status.FATAL, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult);
				break;
			case "SKIP":
				test.log(Status.SKIP, "ACTION: " + sVerification + ", ACTUAL RESULT: " + sActualResult);
				break;
			}
			// insertExecutionStep(sVerification, sActualResult, verdict, true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*******************************************************************************
	 * Description: Method to take screen shot and return screen image location
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param driver
	 * @return Screenshot File Location
	 *****************************************************************************/
	public String captureScreenShot(WebDriver driver) {
		String screenLocation = finalReportPath + "\\ScreenImg" + Integer.toString(StNo++) + ".jpg";
		try {
			/*
			 * Rectangle screenRect = new
			 * Rectangle(Toolkit.getDefaultToolkit().getScreenSize()); BufferedImage capture
			 * = new Robot().createScreenCapture(screenRect); ImageIO.write(capture, "jpg",
			 * new File(screenLocation));
			 */
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(screenLocation));
		} catch (IOException ioe) {
			// TODO Auto-generated catch block
			ioe.printStackTrace();
		} catch (WebDriverException wde) {
			wde.printStackTrace();
		} catch (UnsupportedOperationException uoe) {
			uoe.printStackTrace();
		}
		return screenLocation;
	}

	/********************************************************
	 * Description: Read Entire Text File Content
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param fileLocation
	 * @return Text content of the entire file
	 ******************************************************/
	public String readEntireTextFile(String fileLocation) {
		String currentLine = "";
		try (BufferedReader br = new BufferedReader(new FileReader(new File(fileLocation)))) {
			StringBuilder sb = new StringBuilder();
			currentLine = br.readLine();
			while (currentLine != null) {
				sb.append(currentLine);
				currentLine = br.readLine();
			}
			currentLine = sb.toString();
			br.close();
		} catch (FileNotFoundException e) {
			logReport("Verify File Exist", "File NOT Found at : " + fileLocation, "FAIL", null, false);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return currentLine;
	}

	/********************************************************
	 * Description: Method to write data into Text file
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param filePath
	 * @param content
	 * @param appendValue
	 * @param addNewLine
	 ******************************************************/
	public void writeTextFile(String filePath, String content, boolean appendValue, boolean addNewLine) {
		try {
			File file = new File(filePath);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile(), appendValue);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			if (addNewLine) {
				bw.newLine();
			}
			bw.flush();
			bw.close();
			System.out.println("Done");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/******************************************************************
	 * Description: Method to copy File from source to destination
	 * 
	 * @author Mohammed Rafi Shaik
	 * @param sourceFilePath
	 * @param destinationFolder
	 ****************************************************************/
	@SuppressWarnings("resource")
	public void copyFile(String sourceFilePath, String destinationFolder) {
		try {
			File source = new File(sourceFilePath);
			String fileName = new File(sourceFilePath).getName();
			File destination = new File(destinationFolder + "//" + fileName);

			FileChannel sourceChannel = new FileInputStream(source).getChannel();
			FileChannel destChannel = new FileOutputStream(destination).getChannel();

			destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
			sourceChannel.close();
			destChannel.close();
			System.out.println("File Copy Successful");
		} catch (FileNotFoundException e) {
			logReport("Copy File from Source to Destination", "File NOT Present at - " + sourceFilePath, "FAIL", null,
					false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package com.testing.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;

import com.testing.util.CollectTestData;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Driver {

	public static com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();

	/**
	 * Configures html report
	 * 
	 * @author Mohammed Rafi Shaik
	 */
//	@Test
	public static void baseMethod() {
		// TODO Auto-generated method stub
		htmlLib.configureReport();
	}

	/**
	 * Set Up Initial Script Requirement viz. Create Report, Collect TestData
	 * 
	 * @param tesCasecName, testDescription
	 * @author Mohammed Rafi Shaik
	 */
	public static void setUpTestExecution(String tesCasecName, String testDescription) {
		htmlLib.createReport(tesCasecName, testDescription);
		CollectTestData.main(tesCasecName);
	}

	/**
	 * Sum Up test script execution and erase memory allocated to collection object
	 * used and close browser
	 * 
	 * @param WebDriver driver
	 * @author Mohammed Rafi Shaik
	 */
	public static void sumUpTestScriptExec(WebDriver driver) {
		CollectTestData.testData.clear();
		driver.close();
		driver.quit();
	}

	/**
	 * Launch Browser and Set URL
	 * 
	 * @param browserName
	 * @param url
	 * @return
	 * @author Mohammed Rafi Shaik
	 */
	public static WebDriver launchApplication(String browserName, String url) {
		WebDriver driver = null;
		switch (browserName.toUpperCase()) {
		case "CHROME":
			// Options
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--headless");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
			chromeOptions.merge(capabilities);
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case "FIREFOX":
			FirefoxOptions ffOptions = new FirefoxOptions();
			ffOptions.addArguments("--headless");
			capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, ffOptions);
			ffOptions.merge(capabilities);
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "EDGE":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		case "IE":
			WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
			break;
		}
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(url);
		return driver;
	}

	/**
	 * Marking test execution into Reports
	 * 
	 * @param driver
	 * @param tcName
	 * @param result
	 * @author Mahesh, Mahesh
	 */
	public static void closeExecution(WebDriver driver, String tcName, ITestResult result) {
		if (result.isSuccess()) {
			htmlLib.closeReport(tcName);
		} else if (result.getStatus() == ITestResult.FAILURE) {
			htmlLib.logReport("Test case expected to be Pass!",
					"Test case failure reason: " + result.getThrowable().toString(), "FAIL", driver, true);
			htmlLib.closeReport(tcName);
		} else if (result.getStatus() == ITestResult.SKIP) {
			htmlLib.logReport("Test case expected to be Pass!",
					"Test case skipped reason: " + result.getThrowable().toString(), "SKIP", driver, true);
			htmlLib.closeReport(tcName);
		}
	}

	/**
	 * Marking test execution into Reports - Junit
	 * 
	 * @param driver
	 * @param tcName
	 * @param errorMsg
	 * @author Mahesh, Mahesh
	 */
	public static void closeExecutionJunit(WebDriver driver, String tcName, String errorMsg) {
		if (errorMsg == null) {
			System.out.println(errorMsg);
			Driver.sumUpTestScriptExec(driver);
			htmlLib.closeReport(tcName);
		} else {
			htmlLib.logReport("Test Case got failed!", errorMsg, "FAIL", driver, true);
			Driver.sumUpTestScriptExec(driver);
			htmlLib.closeReport(tcName);
		}
	}

}

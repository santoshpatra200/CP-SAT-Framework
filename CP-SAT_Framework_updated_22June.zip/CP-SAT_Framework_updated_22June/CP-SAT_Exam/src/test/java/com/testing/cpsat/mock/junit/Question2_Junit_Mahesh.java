package com.testing.cpsat.mock.junit;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.testing.base.Driver;
import com.testing.pageObjects.RediffHomePage;
import com.testing.util.CollectTestData;

public class Question2_Junit_Mahesh {
	static WebDriver driver;
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public static com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	static String[] lists = new Question2_Junit_Mahesh().getClass().getName().split("\\.");
	static String tcName = lists[lists.length - 1];
	public static String errorMsg = null;

	@BeforeClass
	public static void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 2 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);

	}

	@Test
	public void test() {
		try {
			String companyName = "HDFC Bank Ltd.";
			String expectedCompanyTitle = "HDFC BANK LTD. - Share Price | Ratios | BSE/NSE Performance | Live Stock Quote";
			String expectedHomeTitle = "Rediff.com: News | Rediffmail | Stock Quotes | Shopping";
			comm.wait(10);
			RediffHomePage homePage = new RediffHomePage(driver);
			// Switch to frame
			WebElement frameEle = driver.findElement(By.xpath("//iframe[@name='moneyiframe']"));
			driver.switchTo().frame(frameEle);
			System.out.println("BSE Value: " + homePage.getBSEValue());
			System.out.println("NSE Value: " + homePage.getNSEValue());
			homePage.enterCompany(companyName);
			driver.switchTo().defaultContent();
			comm.wait(10);
			String currentWindow = driver.getWindowHandle();
			// Get all the handles currently available
			Set<String> handles = driver.getWindowHandles();
			for (String childWindow : handles) {
				if (!childWindow.equalsIgnoreCase(currentWindow)) {
					// Switch to the opened tab
					driver.switchTo().window(childWindow);
					// Verify title of the childWindow
					assertEquals(expectedCompanyTitle, driver.getTitle());
					driver.switchTo().window(currentWindow);
					// Verify title of the currentWindow
					assertEquals(expectedHomeTitle, driver.getTitle());
				}
			}
		} catch (Exception e) {
			errorMsg = "Unexpected exception was thrown" + e.getMessage();
			fail(errorMsg);
		}
	}

	@AfterClass
	public static void closeTest() {
		base.closeExecutionJunit(driver, tcName, errorMsg);
	}

}

package com.testing.cpsat.mock;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;

public class ToolTip {
	static WebDriver driver;
	static String browserName = "chrome";
	static String url = "https://www.demoqa.com/tool-tips/";
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
    String tcName = lists[lists.length-1];
	
	@BeforeMethod
	void setup() {
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Create Multi Segment Booking");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);
	}
	
	@Test
	static void test() throws InterruptedException {
		comm.checkPageReady(driver);
		WebElement toolTipButton=driver.findElement(By.id("toolTipButton"));
		WebElement toolTipBox=driver.findElement(By.id("toolTipTextField"));

		Actions action=new Actions(driver);
		action.moveToElement(toolTipButton).build().perform();
		comm.wait(2);		
		comm.takeScreenShotTip("ToolTip","toolTipButton");
		
		action.moveToElement(toolTipBox).build().perform();
		comm.wait(2);		
		comm.takeScreenShotTip("ToolTip","toolTipsearchBox");
	}
	
	@AfterMethod
	public void closeTest() {
		Driver.sumUpTestScriptExec(driver);
		htmlLib.closeReport(tcName);
	}

}

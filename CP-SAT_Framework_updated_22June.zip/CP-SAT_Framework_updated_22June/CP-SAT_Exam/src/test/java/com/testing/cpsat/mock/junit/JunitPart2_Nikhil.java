package com.testing.cpsat.mock.junit;

import static org.testng.Assert.fail;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.ITestResult;
//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.BeforeMethod;
//import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;

public class JunitPart2_Nikhil {
	static WebDriver driver;
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	static String[] lists = new JunitPart2_Nikhil().getClass().getName().split("\\.");
	static String tcName = lists[lists.length - 1];
	String parent_page_window_handle;
	public static String errorMsg=null;

	@BeforeClass
	public static void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 1 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);

	}

	@Test
	public void test() throws InterruptedException {
		try {
			driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
			driver.findElement(By.xpath("//*[@class='allow']")).click();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			Robot robot=new Robot();
			//Thread.sleep(3000);
			comm.wait(3);
			if(driver.findElement(By.xpath("//*[@id='jsw-close']")).isDisplayed()) {
				driver.findElement(By.xpath("//*[@id='jsw-close']")).click();
				System.out.println("Songs close window button clicked");
			}else {
				System.out.println("Songs close window button not displayed");
			}
			parent_page_window_handle=driver.getWindowHandle();

			List<WebElement> list=driver.findElements(By.xpath("//*[@class='widcont_topstories']//a"));    		
			for(int i=0;i<list.size();i+=2) {
				System.out.println("Each Top story href is "+list.get(i).getAttribute("href"));
			}

			Actions actions=new Actions(driver);
			WebElement coporates=driver.findElement(By.xpath("//*[contains(text(),' Corporates')]"));
			if(coporates.isDisplayed()==true){
				//actions.moveToElement(coporates).keyDown(Keys.LEFT_CONTROL).click(coporates).keyUp(Keys.LEFT_CONTROL).build().perform();
				actions.moveToElement(coporates).contextClick(coporates).build().perform();
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				System.out.println("Coporates open in New Tab");
				//Thread.sleep(5000);
				comm.wait(5);
				Set<String> windowHandles=driver.getWindowHandles();
				for(String each_windowhandle:windowHandles) {
					if(!each_windowhandle.equalsIgnoreCase(parent_page_window_handle)) {
						driver.switchTo().window(each_windowhandle);
						String coporate_page_title=driver.getTitle();
						System.out.println("Coporate Page Title is "+coporate_page_title);
					}
				}

			}else {
				System.out.println("Coporates Tag is not visible");
			}

			//On the same page for "Corporates" get the Href of top 3 stories on the page (2 marks) (Screenshot is needed at this stage)
			List<WebElement> top_links=driver.findElements(By.xpath("//*[@class='s-ls_ul s-ls_br']//a"));
			System.out.println("Top 3 Stories Trending on Coporates Page is ");
			int count=0;
			for(int i=0;i<top_links.size();i+=2) {
				System.out.println(top_links.get(i).getAttribute("href"));
				count++;
				if(count>2) {
					break;
				}
			}
			htmlLib.logReport("Take screenshot of Trending stories on Coporates Page", "Top 3 stories Trending on Coporates page must be visible", "PASS", driver, true);
			//Print the title of <https://www.ndtv.com/business> (2.5 marks) 
			driver.switchTo().window(parent_page_window_handle);
			String business_page_title=driver.getTitle();
			System.out.println("The Business Page Title is "+business_page_title);

		}
		catch(Exception e) {
			e.printStackTrace();
			errorMsg = "Unexpected exception was thrown" + e.getMessage();
			fail(errorMsg);
		}
	}

	@AfterClass
	public static void closeTest() {
		base.closeExecutionJunit(driver, tcName, errorMsg);
	}





}


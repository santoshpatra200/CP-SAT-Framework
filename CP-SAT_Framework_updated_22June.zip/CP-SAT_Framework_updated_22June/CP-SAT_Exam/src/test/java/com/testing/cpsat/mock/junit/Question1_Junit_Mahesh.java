package com.testing.cpsat.mock.junit;

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;

import io.github.bonigarcia.wdm.WebDriverManager;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;

public class Question1_Junit_Mahesh extends RunListener {
	static WebDriver driver;
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public static com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	static String[] lists = new Question1_Junit_Mahesh().getClass().getName().split("\\.");
	static String tcName = lists[lists.length - 1];
	public static String errorMsg = null;

	@BeforeClass
	public static void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 1 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);

	}

	@Test
	public void test() throws IOException {
		try {

			comm.wait(10);
			List<WebElement> webelements = driver
					.findElements(By.xpath("//div[text()='TOP STORIES']/../following-sibling::div[1]/h2/a"));

			File loc = new File(System.getProperty("user.dir") + "\\TestData\\StoreData.txt");
			BufferedWriter writer = Files
					.newBufferedWriter(Paths.get(System.getProperty("user.dir") + "\\TestData\\StoreData.txt"));
			writer.write("");
			writer.flush();
			for (int i = 0; i < webelements.size(); i++) {
				String link = webelements.get(i).getText();
				String link2 = link + "\n";
				System.out.println(link2);
				writer.write(link2);

			}
			writer.close();
		} catch (Exception e) {
			errorMsg = "Unexpected exception was thrown" + e.getMessage();
			fail(errorMsg);
		}
	}

	@AfterClass
	public static void closeTest() {
		base.closeExecutionJunit(driver, tcName, errorMsg);
	}

}

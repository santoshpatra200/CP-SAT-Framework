package com.testing.cpsat.mock;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;
import com.testing.util.CommonLibrary;
import com.testing.util.ExcelReader;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Question2_Prashanth {
	static WebDriver driver;
	static String browserName = "chrome";
	static String url = "https://www.rediff.com/";
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
	String tcName = lists[lists.length - 1];
	CommonLibrary cl = new CommonLibrary();
	public Object[][] testData;

	@SuppressWarnings("deprecation")
	@BeforeMethod
	void setup() throws Exception {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question2_Prashanth");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);
		
	}

	@DataProvider
	public Object[][] dataProvFunc() throws Exception {
		testData = ExcelReader.getTableArray(System.getProperty("user.dir") + "\\TestData\\TestData.xlsx",
				"Prash_Data2");
		return (testData);
	}

	@Test(dataProvider = "dataProvFunc")
	void test(String Menu, String Href) throws InterruptedException, IOException {
		cl.checkPageReady(driver);
		WebElement menuEle = driver.findElement(By.xpath("//a[contains(@title,'" + Menu + "')]"));
		String actMenuName = menuEle.getText();
		assertTrue((actMenuName).equalsIgnoreCase(Menu));
		menuEle.click();
		String actMenuUrl = driver.getCurrentUrl();
		assertTrue(actMenuUrl.contains(Href), "Verifying the URL");
		System.out.println("Actual URL:"+actMenuUrl + '\n' + "Expected URL: "+Href);
	}

	@AfterMethod
	public void closeTest(ITestResult result) {
		base.closeExecution(driver, tcName, result);
		Driver.sumUpTestScriptExec(driver);
	}
}

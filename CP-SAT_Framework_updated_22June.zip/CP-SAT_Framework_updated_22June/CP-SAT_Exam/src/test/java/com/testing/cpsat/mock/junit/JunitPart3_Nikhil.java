package com.testing.cpsat.mock.junit;

import static org.testng.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.testng.annotations.BeforeMethod;
//import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;

public class JunitPart3_Nikhil {
	static WebDriver driver;
	static String browserName = "chrome";
	static String url = "https://www.google.com/";
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	static String[] lists = new JunitPart3_Nikhil().getClass().getName().split("\\.");
	static String tcName = lists[lists.length - 1];
	static String errorMsg=null;

	@BeforeClass
	public static void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 1l mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);

	}

	@Test
	public void test() {
		try {
			System.out.println("INside TestngPart3");
			comm.wait(5);
		}catch(Exception e) {
			e.printStackTrace();
			errorMsg = "Unexpected exception was thrown" + e.getMessage();
			fail(errorMsg);
		}
		

	}
	
	@AfterClass
	public static void closeTest() {
		base.closeExecutionJunit(driver, tcName, errorMsg);
	}
	
	
}
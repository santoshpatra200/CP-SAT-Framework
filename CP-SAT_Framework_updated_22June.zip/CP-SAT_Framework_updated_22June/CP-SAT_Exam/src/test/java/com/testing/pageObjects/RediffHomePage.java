package com.testing.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class RediffHomePage {

	By bseValue = By.xpath("//span[text()='BSE']/following-sibling::span");
	By nseValue = By.xpath("//span[text()='NSE']/following-sibling::span");
	By companytxtbx = By.xpath("//input[@name='query']");
	WebDriver driver;
	
	public RediffHomePage(WebDriver driver) {
		this.driver=driver;
	}
	
	public String getBSEValue() {
		return driver.findElement(bseValue).getText();		
	}
	
	public String getNSEValue() {
		return driver.findElement(nseValue).getText();		
	}
	
	public void enterCompany(String company) {
		driver.findElement(companytxtbx).sendKeys(company, Keys.ENTER);
	}

}

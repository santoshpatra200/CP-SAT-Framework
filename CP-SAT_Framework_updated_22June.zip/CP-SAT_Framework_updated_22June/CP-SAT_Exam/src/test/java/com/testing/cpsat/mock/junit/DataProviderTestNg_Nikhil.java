package com.testing.cpsat.mock.junit;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Window;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;

import io.opentelemetry.exporter.logging.SystemOutLogExporter;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DataProviderTestNg_Nikhil {
	File file;
	FileInputStream fis;
	XSSFWorkbook workbook;
	FileOutputStream fos;
	HashMap<String,Object[]> resultData;
	File resulttantFile;
	static WebDriver driver;
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
	String tcName = lists[lists.length - 1];
	String parent_page_window_handle;


	@BeforeMethod
	void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 1 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);

	}



	@DataProvider
	public ArrayList<HashMap<String,String>> getParticipantData() {
		ArrayList participantDataList=new ArrayList<>();
		try {
			file=new File(System.getProperty("user.dir")+"\\TestData\\Participant_List.xlsx");
			fis=new FileInputStream(file);
			workbook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int rowcount=sheet.getLastRowNum();


			for(int i=1;i<=rowcount;i++) {
				HashMap<String,String> participantDataMap=new HashMap<String,String>();
				XSSFRow row=sheet.getRow(i);
				String TestName=row.getCell(0).getStringCellValue();
				String Name=row.getCell(1).getStringCellValue();
				String Designation=row.getCell(2).getStringCellValue();
				String OrganizationName=row.getCell(3).getStringCellValue();
				participantDataMap.put("TestName", TestName);
				participantDataMap.put("Name", Name);
				participantDataMap.put("Designation", Designation);
				participantDataMap.put("OrganizationName", OrganizationName);
				participantDataList.add(participantDataMap);		

			}
			System.out.println(participantDataList);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return participantDataList;

	}


	public int getRowCountOnPresenceOfData(String participantName) {
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		int requiredRowNumber=0;
		int rowCount=sheet.getLastRowNum();
		for(int i=0;i<rowCount;i++) {
			if(sheet.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase(participantName)) {
				requiredRowNumber=i;
			}
		}

		return requiredRowNumber;
	}





	public void writeResultantDataIntoFile() throws IOException {
		//resulttantFile=new File(System.getProperty("user.dir")+"\\TestData\\ResultantFile.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook();
		XSSFSheet resultsheet=workbook.createSheet("Resultantsheet");
		Set<String> keys=resultData.keySet();
		int rowcount=0;
		for(String eachKey:keys) {
			Object[] values=resultData.get(eachKey);
			XSSFRow row=resultsheet.createRow(rowcount);
			int cellCount=0;
			for(Object eachValue:values) {
				row.createCell(cellCount).setCellValue((String)eachValue);
				cellCount++;

			}
			rowcount++;
		}
		FileOutputStream fos=new FileOutputStream(new File(System.getProperty("user.dir")+"\\TestData\\ResultantFile.xlsx"));
		workbook.write(fos);
		fos.close();
	}


	@Test
	public void question2() throws AWTException, InterruptedException, IOException {
		Actions actions=new Actions(driver);
		Robot robot=new Robot();
		driver.manage().window().maximize();
		String parent_window_handle=driver.getWindowHandle();
		System.out.println("Parent window handle is "+parent_window_handle);
		driver.findElement(By.xpath("//*[@class='eicon-close']")).click();
		System.out.println("Close registeration button successfully closed");
		driver.findElement(By.xpath("(//a[@href='#'])[2]")).click();
		driver.findElement(By.xpath("//*[contains(text(),'List of Participants')]")).click();
		List participantList=getParticipantData();

		JavascriptExecutor jse=(JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,1000)");
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[contains(@data-ninja_table_instance,'ninja_table_instance')]")));

		resultData=new HashMap<String,Object[]>();

		for(int i=0;i<participantList.size();i++) {
			HashMap<String,String> hm=(HashMap<String, String>) participantList.get(i);
			String participantName=hm.get("Name");
			String participantDesignation=hm.get("Designation");
			String participantOrganizationName=hm.get("OrganizationName");
			System.out.println("Participant name is "+participantName);
			driver.findElement(By.xpath("//input[@placeholder='Search']")).clear();
			System.out.println("Validation for Participant Name "+participantName);
			driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(participantName);
			int rowNumber=getRowCountOnPresenceOfData(participantName);
			System.out.println("The row number on which the given particiapnt name is found is "+rowNumber);;
			Thread.sleep(5000);
			WebElement tabledata=driver.findElement(By.xpath("//table[contains(@data-ninja_table_instance,'ninja_table_instance')]"));
			List<WebElement> tablebodylist=tabledata.findElements(By.tagName("tbody"));
			for(int k=0;k<tablebodylist.size();i++) {
				WebElement tablebody=tablebodylist.get(k);
				List<WebElement> tablerows=tablebody.findElements(By.tagName("tr"));
				for(WebElement eachTablerow:tablerows) {
					List<WebElement> cellDataList=eachTablerow.findElements(By.tagName("td"));
					String participantNameRetrievedFromHtmlTable=cellDataList.get(1).getText();
					String participantDesignationRetrievedFromHtmlTable=cellDataList.get(2).getText();
					String participantOrgainzationNameRetrievedFromHtmlTable=cellDataList.get(3).getText();
					//System.out.println("Data retrieved from the excel for "+participantName+ "is "+participantName+"data retrieved from html table is "+participantNameRetrievedFromHtmlTable);
					//System.out.println("Data retrieved from the excel for "+participantName+ "is "+participantDesignation+"data retrieved from html table is "+participantDesignationRetrievedFromHtmlTable);
					//System.out.println("Data retrieved from the excel for "+participantName+ "is "+participantOrganizationName+"data retrieved from html table is "+participantOrgainzationNameRetrievedFromHtmlTable);

					int count=0;
					if(!participantNameRetrievedFromHtmlTable.equalsIgnoreCase(participantName)) {
						count++;
					}
					if(!participantDesignationRetrievedFromHtmlTable.equalsIgnoreCase(participantDesignation)) {
						count++;
					}
					if(!participantOrgainzationNameRetrievedFromHtmlTable.equalsIgnoreCase(participantOrganizationName)) {
						count++;	
					}
					if(count >0) {
						System.out.println("Participant data in the excel and in the Html table are not congurent");
						try {
							resultData.put(participantName, new Object[] {participantName,participantDesignation,participantOrganizationName,"Fail"});
						} catch (Exception e) {
							e.printStackTrace();
						}
					}else {
						System.out.println("Participant data in excel and the HTML table are congurent");
						resultData.put(participantName, new Object[] {participantName,participantDesignation,participantOrganizationName,"Pass"});
					}

				}
				break;
			}

		}
		System.out.println("The resulttant Data to be printed in the excel sheet is "+resultData);
		writeResultantDataIntoFile();
		System.out.println("Resultant data added in the new Resultant file");

	}


	@AfterMethod
	public void closeTest(ITestResult result) {
		base.closeExecution(driver, tcName, result);
		Driver.sumUpTestScriptExec(driver);
	}
}


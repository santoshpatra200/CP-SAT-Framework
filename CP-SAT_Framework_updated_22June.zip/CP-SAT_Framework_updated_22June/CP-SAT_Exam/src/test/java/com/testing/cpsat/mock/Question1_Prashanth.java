package com.testing.cpsat.mock;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;
import com.testing.util.CommonLibrary;
import com.testing.util.ExcelReader;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

public class Question1_Prashanth {
	static WebDriver driver;
	static String browserName = "chrome";
	static String url = "https://www.rediff.com/";
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
	String tcName = lists[lists.length - 1];
	CommonLibrary commonLibObj = new CommonLibrary();

	@BeforeMethod
	void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question1_Prashanth");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);
		 
	}

	@Test
	void test() throws InterruptedException, IOException {
		String testDataDir = System.getProperty("user.dir")+"\\TestData\\TestData.xlsx";
		ExcelReader excelReaderObj = new ExcelReader(testDataDir,"Prash_Data");
		Map<String, Map<String, String>> excelData = excelReaderObj.getExcelAsMap();	
		comm.wait(10);
		driver.findElement(By.linkText("MOVIES")).click();
		
		for (int i = 1; i <= excelData.size(); i++) {
			int moviesCount =0;
			comm.wait(2);
			commonLibObj.checkPageReady(driver);	
			String Tab = excelData.get(""+i+"").get("SubMenu");
			driver.findElement(By.xpath("//a[contains(text(),'"+Tab+"')]")).click();
			commonLibObj.takeScreenShot(driver,"Question1_Prashanth_"+Tab);
			String actSubMenuUrl = driver.getCurrentUrl();
			String expSubMenuUrl = (excelData.get(""+i+"").get("Expected HREF").toString());
			assertTrue(actSubMenuUrl.contains(expSubMenuUrl),"Verifying the SubMenu URL");
			System.out.println("Actual URL:"+actSubMenuUrl + '\n' + "Expected URL: "+expSubMenuUrl);
			comm.wait(5);
			 moviesCount = driver.findElements(By.xpath("//div[contains(text(),'MOVIES')]")).size();
			if(moviesCount>=1) {
			driver.findElement(By.xpath("//*[contains(text(),'MOVIES')]")).click();
			}
		}


	}

	@AfterMethod
	public void closeTest(ITestResult result) {
		base.closeExecution(driver, tcName, result);
		Driver.sumUpTestScriptExec(driver);
	}
}

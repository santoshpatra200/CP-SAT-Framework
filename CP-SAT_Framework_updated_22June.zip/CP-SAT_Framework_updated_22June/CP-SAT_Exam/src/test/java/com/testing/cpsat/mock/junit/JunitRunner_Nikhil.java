package com.testing.cpsat.mock.junit;
import org.junit.runner.RunWith;		
import org.junit.runners.Suite;	


@RunWith(Suite.class)				
@Suite.SuiteClasses({				
    JunitPart2_Nikhil.class,			
    JunitPart3_Nikhil.class,			

})		
public class JunitRunner_Nikhil {
	

}

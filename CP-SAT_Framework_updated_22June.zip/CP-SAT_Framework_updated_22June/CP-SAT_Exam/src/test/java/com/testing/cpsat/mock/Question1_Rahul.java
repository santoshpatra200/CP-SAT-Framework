package com.testing.cpsat.mock;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.testing.base.Driver;
import com.testing.util.CollectTestData;

public class Question1_Rahul {

	
	static WebDriver driver;
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
	String tcName = lists[lists.length - 1];
	    
	    @BeforeMethod
		void setup() {
	    	base.baseMethod();
			// Set Up Initial Script Requirement
			Driver.setUpTestExecution(tcName, "Question 1 mock");
			// launch application
			String browser = CollectTestData.browser;
			String url = CollectTestData.url;
			driver = Driver.launchApplication(browser, url);
		}
		
	    @Test
		void test() throws InterruptedException {
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("No Thanks")));
			driver.findElement(By.linkText("No Thanks")).click();
			
			driver.switchTo().frame(1);
			WebElement site = driver.findElement(By.xpath("//select[@id='type']"));
			site.click();
			htmlLib.logReport("Take screenshot of site options", "Site options screenshot must be captured", "PASS", driver, true);
			
			Select sel = new Select(driver.findElement(By.xpath("//select[@id='type']")));
			sel.selectByValue("FNOStock");
			htmlLib.logReport("Take screenshot of Selected FNO option", "selected FNO option screenshot must be captured", "PASS", driver, true);
			
			driver.findElement(By.xpath("//input[@class='search-input']")).sendKeys("TCS");
			driver.findElement(By.className("search-icon")).click();
			driver.switchTo().defaultContent();
			
			WebElement element = driver.findElement(By.xpath("//div[@id='videos']/div/div/ul/li/div/div/a"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
						
		    List<WebElement> videos = driver.findElements(By.xpath("//div[@id='videos']/div/div/ul/li/div/div/a"));
		    System.out.println("Total videos on the Web Page: " + videos.size());
		    
		    Assert.assertTrue(videos.size()>1);
		    
		    String firstVideolink = videos.get(0).getAttribute("href");
		    driver.navigate().to(firstVideolink);
	    }
	    
	    @AfterMethod
		public void closeTest(ITestResult result) {
			base.closeExecution(driver, tcName, result);
			Driver.sumUpTestScriptExec(driver);
		}


	}



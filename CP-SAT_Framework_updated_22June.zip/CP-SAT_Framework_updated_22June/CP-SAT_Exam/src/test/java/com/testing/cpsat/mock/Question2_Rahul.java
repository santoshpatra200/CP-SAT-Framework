package com.testing.cpsat.mock;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.testing.base.Driver;
import com.testing.util.CollectTestData;

public class Question2_Rahul {

	
		static WebDriver driver;
		public static com.testing.base.Driver base = new com.testing.base.Driver();
		public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
		public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
		String[] lists = this.getClass().getName().split("\\.");
		String tcName = lists[lists.length - 1];
	    public static String firstElement;
	    
	    
	    
	    @BeforeMethod
		void setup() {
	    	base.baseMethod();
			// Set Up Initial Script Requirement
			Driver.setUpTestExecution(tcName, "Question 1 mock");
			// launch application
			String browser = CollectTestData.browser;
			String url = CollectTestData.url;
			driver = Driver.launchApplication(browser, url);
		}
		
	    @Test
		void test() throws InterruptedException {
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("No Thanks")));
			driver.findElement(By.linkText("No Thanks")).click();
			
			driver.switchTo().frame(1);		
									
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='mkt-indicator'] //a[contains(@href,'gold')]/span //span[@class='green-btn fl']"))));
			String goldPriceChange = driver.findElement(By.xpath("//div[@class='mkt-indicator'] //a[contains(@href,'gold')]/span //span[@class='green-btn fl']")).getText();
			String actualbackgroundcolor = driver.findElement(By.xpath("//div[@class='mkt-indicator'] //a[contains(@href,'gold')]/span //span[@class='green-btn fl']")).getCssValue("background-color").toString();
			
			System.out.println("Change is gold price in percentage : " + goldPriceChange.split("\\(")[1].split("\\%")[0]+"%");
			System.out.println("Change is gold price in number : " + goldPriceChange.split("\\(")[0]);
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='mkt-indicator'] //a[contains(@href,'gold')]/span/span[1]"))));
			String goldPrice = driver.findElement(By.xpath("//div[@class='mkt-indicator'] //a[contains(@href,'gold')]/span/span[1]")).getText();
			
			System.out.println("Gold price : " + goldPrice);
			
			String expectedBackgroundColor = "rgba(12, 162, 2, 1)";
			
			Assert.assertEquals(actualbackgroundcolor, expectedBackgroundColor, "Background color is green");
			
			driver.switchTo().defaultContent();
			
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//div[@class='bx-controls-direction'] //a[@class='bx-prev']")));
			
			 
			driver.switchTo().frame(driver.findElement(By.xpath("//div[@class='nwid_mid ppwidget']/iframe")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='By Gain']")));
			driver.findElement(By.xpath("//a[@id='By Gain']")).click();
			Thread.sleep(3000);			 
			System.out.println("Clicked on By Gain link");
			 
			Actions actions = new Actions(driver);
			
			
			WebElement ele = driver.findElement(By.xpath("//ul[@id='peerlist2']/li[1]/a"));
			
			 
			actions.moveToElement(ele).build().perform();
			
			htmlLib.logReport("Take screenshot of 1st selected company", "1st selected company screenshot must be captured", "PASS", driver, true);
						
			String firstCompany = ele.getText();
			String [] firstarray = firstCompany.split("\\r\\n|\\n|\\r");
			
			
			System.out.println("First company name : " + firstarray[0]);
			System.out.println("First company gain percentage : " + firstarray[1].split("\\%")[0]);
			System.out.println("First cell's RGB value : " + driver.findElement(By.xpath("//ul[@id='peerlist2']/li[1]")).getCssValue("background-color"));
			
			driver.findElement(By.xpath("//a[@id='Alphabetical']")).click();
			Thread.sleep(6000);
						
			List<WebElement> elements = driver.findElements(By.xpath("//ul[@id='peerlist2']/li/a"));
			
			//firstElement = elements.get(0).getText().split("\\r\\n|\\n|\\r")[0];
			firstElement = elements.get(0).getAttribute("title");
			for(WebElement e : elements)
			{
							
				//String secondElement = e.getText().split("\\r\\n|\\n|\\r")[0];
				
				String secondElement = e.getAttribute("title");
				
				if(firstElement.equalsIgnoreCase(secondElement))
				{
				
				}
				
				else
				{
					//System.out.println("First Element : "+firstElement);
					//System.out.println("Second Element : "+secondElement);
					
					Assert.assertTrue((firstElement.compareTo(secondElement))<0);
					firstElement = secondElement;
					
				}
								
			}
						
	    }
	           
	    @AfterMethod
	  		public void closeTest(ITestResult result) {
	  			base.closeExecution(driver, tcName, result);
	  			Driver.sumUpTestScriptExec(driver);
	  		}

	}



package com.testing.cpsat.mock;

import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.pageObjects.NdtvHomePage;
import com.testing.util.CollectTestData;

import org.testng.annotations.BeforeMethod;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

public class Question2_Rafi {
	static WebDriver driver;
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
	String tcName = lists[lists.length - 1];
	public static String errorMsg = null;
  
	@BeforeMethod
	void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 2 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);
	}
	
	@Test
	void accept_alert_test() {
		try {
			/**
			 * Get the top level titles and print
			 */
			NdtvHomePage ndtvHomePage = new NdtvHomePage(driver);
			ndtvHomePage.homePageLoad().isDisplayed();
			List<WebElement> header_links = ndtvHomePage.getTopLevelList();
			List<String> print_headers = new ArrayList<String>();
			List<String> print_footers = new ArrayList<String>();;
			for(WebElement header_links_text : header_links)
			{	
				print_headers.add(header_links_text.getText());
			}
			System.out.println("Top level headers :" + print_headers);
			
			/**
			 * Get the footer level titles and print
			 */
			comm.scrollDown(driver);
			List<WebElement> footer_links = ndtvHomePage.footerLevelList();
			for(WebElement footer_links_text : footer_links) {
				
				print_footers.add(footer_links_text.getText());
			}
			System.out.println("Footer level headers :" + print_footers);
			
			/**
			 * Check if the hrefs for Business on the top level and the bottom menu are same or not, if they are not then Assert fail the test
			 */
			try {
				Assert.assertTrue(header_links.size() == footer_links.size() && header_links.containsAll(footer_links) && footer_links.containsAll(header_links));
				htmlLib.logReport("Verify that header links is equal to footer links", "header links is matching with footer links", "PASS", driver, false);
			}catch (Exception e) {
				htmlLib.logReport("Verify that header links is equal to footer links", "header links is not matching with footer links" + e.getMessage(), "FAIL", driver, false);
			}
		}catch (Exception e) {
			errorMsg = "Unexpected exception was thrown" + e.getMessage();
			fail(errorMsg);
		}
		
	}
	
	@AfterMethod
	public void closeTest(ITestResult result) {
		base.closeExecution(driver, tcName, result);
		Driver.sumUpTestScriptExec(driver);
	}

}

package com.testing.cpsat.mock;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Question1_Mahesh {
	static WebDriver driver;
	static String browserName = "chrome";
	static String url = "https://www.rediff.com/";
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
	String[] lists = this.getClass().getName().split("\\.");
	String tcName = lists[lists.length - 1];

	@BeforeMethod
	void setup() {
		base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 1 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);

	}

	@Test
	void test() throws InterruptedException, IOException {
		comm.wait(10);
		List<WebElement> webelements = driver
				.findElements(By.xpath("//div[text()='TOP STORIES']/../following-sibling::div[1]/h2/a"));

		File loc = new File(System.getProperty("user.dir") + "\\TestData\\StoreData.txt");
		BufferedWriter writer = Files
				.newBufferedWriter(Paths.get(System.getProperty("user.dir") + "\\TestData\\StoreData.txt"));
		writer.write("");
		writer.flush();
		for (int i = 0; i < webelements.size(); i++) {
			String link = webelements.get(i).getText();
			String link2 = link + "\n";
			System.out.println(link2);
			writer.write(link2);

		}
		writer.close();
	}

	@AfterMethod
	public void closeTest(ITestResult result) {
		base.closeExecution(driver, tcName, result);
		Driver.sumUpTestScriptExec(driver);
	}
}

package com.testing.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class NdtvHomePage {
	//public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
	By topLevelTitles = By.xpath("//div[@class='nglobalnav']//a");
	By footerLevelTitle = By.xpath("//div[@class='footer_group']//li//a");
	By homePageLoaded = By.xpath("//div[@class='budgetlogo2016cont']//a[@href='https://www.ndtv.com/business']");
	WebDriver driver;
	
	public NdtvHomePage(WebDriver driver) {
		this.driver=driver;
	}
	
	public List<WebElement> getTopLevelList() {
		List<WebElement> header_links = driver.findElements(topLevelTitles);
		return header_links;
	}
	
	public List<WebElement> footerLevelList() {
		List<WebElement> footer_links = driver.findElements(footerLevelTitle);
		return footer_links;
	}
	
	public WebElement homePageLoad() {
		return driver.findElement(homePageLoaded);		
	}

}

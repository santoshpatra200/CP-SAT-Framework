package com.testing.cpsat.mock;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.Driver;
import com.testing.util.CollectTestData;

public class Question3 {
	static WebDriver driver;
	static String browserName = "chrome";
	static String url = "https://www.cii.in/";
	public static com.testing.base.Driver base = new com.testing.base.Driver();
	public static com.testing.util.CommonLibrary comm = new com.testing.util.CommonLibrary();
    public com.testing.util.ReportLibrary htmlLib = new com.testing.util.ReportLibrary();
    String[] lists = this.getClass().getName().split("\\.");
    String tcName = lists[lists.length-1];
	
    @BeforeMethod
	void setup() {
    	base.baseMethod();
		// Set Up Initial Script Requirement
		Driver.setUpTestExecution(tcName, "Question 3 mock");
		// launch application
		String browser = CollectTestData.browser;
		String url = CollectTestData.url;
		driver = Driver.launchApplication(browser, url);
	}
	
	@Test
	void test() throws InterruptedException {
		WebElement ciiServices = driver.findElement(By.xpath("(//a[contains(text(),'CII Services')])[2]")); 
		comm.waitForElementToClickable(driver, ciiServices);
		Actions action = new Actions(driver); 
		action.moveToElement(ciiServices).build().perform();

		WebElement sectoralPortfolio = driver.findElement(By.xpath("//a[contains(text(),'Sectoral Portfolio')]"));
		comm.waitForElementToClickable(driver, sectoralPortfolio);
		action.moveToElement(sectoralPortfolio).build().perform();

		WebElement foodAndAgriculture = driver.findElement(By.xpath("//a[contains(text(),'Food & Agricultural')]"));
		comm.waitForElementToClickable(driver, foodAndAgriculture);
		action.moveToElement(foodAndAgriculture).build().perform();
		
		WebElement agriculture = driver.findElement(By.xpath("//a[contains(text(),'Agriculture')]"));
		comm.waitForElementToClickable(driver, agriculture);
		comm.jsClick(driver, agriculture);
		comm.checkPageReady(driver);

		System.out.println("Page Title: "+driver.getTitle());

		List<WebElement> list = driver.findElements(By.xpath("//div[@class='new-socila-icons']")); 
		for (int i = 0 ; i<list.size(); i++) {
			
			comm.waitForElementToVisible(driver, list.get(i));
			//scrollIntoView(list.get(i));
			comm.wait(2);
			action.moveToElement(list.get(i)).clickAndHold().build().perform();
			comm.wait(2);
			htmlLib.logReport("Take screenshot of social icon", "Social icon screenshot must be capture", "FAIL", driver, true);
			//comm.takeScreenShotTip("Q3_tool_tip_", String.valueOf((i+1)));
			System.out.println(list.get(i).getAttribute("title"));		
			
		}
	}
	
	@AfterMethod
	public void closeTest(ITestResult result) {
		base.closeExecution(driver, tcName, result);
		Driver.sumUpTestScriptExec(driver);
	}
}
